<template>
  <view>list-item</view>
</template>

<script>
export default {

}
</script>

<style>

</style>