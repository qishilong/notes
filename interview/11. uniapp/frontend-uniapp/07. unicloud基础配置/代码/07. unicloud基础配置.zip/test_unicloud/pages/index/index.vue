<template>
	<view>
		<button type="default" @click="getData">调用云函数使用callback的形式进行云函数的调用</button>
		<button type="default" @click="pormiseSendData">使用promise调用</button>
	</view>
</template>

<script>
	export default {
		methods: {
			getData() {
				uniCloud.callFunction({
					name:'test_level_1',
					data:{
						userName:'alan',
						age:20
					},
					success(res) {
						console.log(res)
					}
				})
			},
			async pormiseSendData() {
				const res = await uniCloud.callFunction({
					name:"test_level_2",
					data:{msg:'你好，china'}
				})
				console.log(res)
			}
		},
	}
</script>

<style scoped>

</style>