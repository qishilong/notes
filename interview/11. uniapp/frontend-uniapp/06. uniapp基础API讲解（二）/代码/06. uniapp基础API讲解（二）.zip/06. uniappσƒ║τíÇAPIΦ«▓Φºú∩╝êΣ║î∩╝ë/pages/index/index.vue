<template>
	<view>
		<button type="default" @click="getData">获取数据内容</button>
		<button type="default" @click="unloadImg">上传图片</button>
		<button type="default" @click="saveStorage">设置本地存储数据</button>
		<button type="default" @click="showDialog">显示弹窗</button>
		<button type="default" @click="goOtherPage">跳转到其他界面</button>

		<!-- #ifdef H5 -->
		<view class="demo">
			只能在html5中进行显示
		</view>
		<!-- #endif -->
		
		<!-- #ifndef H5 -->
		<text>除了h5平台，其他的平台都可以实现显示</text>
		<!-- #endif -->
		
		<!-- #ifdef APP-PLUS | H5 -->
			<text>只有app及html5进行的显示的内容</text>
		<!-- #endif -->
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInfo: {
					name: "alan",
					age: 20
				},
				obj: {
					name: "job",
					age: 60
				}
			}
		},
		methods: {
			async getData() {
				this.$http.beforeRequest = function(options) {
					// do somethimg...
					console.log('请求之前---', options)
				}
				this.$http.afterRequest = function() {
					// do something...
					console.log('请求完成')
				}
				const res = await this.$http.get('https://study.duyiedu.com/api/herolist')
				console.log(res)

				// const res = await fetch('https://study.duyiedu.com/api/herolist')
				// const result = await res.json()
				// console.log(result)
				// return 

				// uni.request({
				// 	url:'https://study.duyiedu.com/api/herolist',
				// 	success(res) {
				// 		console.log(res)
				// 	}
				// })
			},
			unloadImg() {
				uni.chooseImage({ // 从本地相册或者是照相机里面进行一个图片或者是多个图片的选择，获取到一个或多个图片的地址
					success: (chooseImageRes) => {
						const tempFilePaths = chooseImageRes.tempFilePaths; //获取到图片信息
						/* 图片的上传 */
						uni.uploadFile({
							url: 'https://up-as0.qiniup.com', // 图片的上传地址，一般是后端提供
							filePath: tempFilePaths[0], // 只传递我们选择的图片的第一张上传
							name: 'file',
							formData: {
								/* 七牛需要的信息内容*/
								key: `${Date.now()}.jpg`,
								token: '8QQD0qX3ER_tMNfKMeYfueFECLJW1Zyg7zExska0:fFDCoMXZmjn0EyU4OUmdazK1A4k=:eyJjYWxsYmFja0JvZHlUeXBlIjoiYXBwbGljYXRpb24vanNvbiIsInJldHVybkJvZHkiOiJ7XCJ1cmxcIjpcImh0dHBzOi8vbGVodWltZy5oeWZhcnNpZ2h0LmNvbS8kKGtleSlcIixcImNvZGVcIjowfSIsInNjb3BlIjoicGMtcHJvamVjdCIsImRlYWRsaW5lIjoxNjU4Mzk1OTg1fQ=='
							},
							success: (uploadFileRes) => {
								console.log(uploadFileRes.data);
							}
						});
					}
				});
			},
			/* 设置本地存储 */
			saveStorage() {
				// uni.setStorageSync('userInfo1',this.obj)
				const user = uni.getStorageSync('userInfo1')
				console.log(user)
				// uni.setStorage({
				// 	key:'userInfo',
				// 	data:this.userInfo,
				// 	success(res) {
				// 		console.log(res)
				// 	}
				// })
				// uni.getStorage({
				// 	key:"userInfo",
				// 	success(res) {
				// 		console.log(res)
				// 	}
				// })
			},
			showDialog() {
				uni.showToast({
					title: '对话框标题',
					icon: 'success'
				})
			},
			goOtherPage() {
				uni.navigateTo({
					url: '/pages/other/other?name=job&age=20'
				})
			}
		},
	}
</script>

<style scoped lang="scss">
	.demo {
		// color: red;
		font-size: 30px;
		color :$uni-color-title;
	}
	/* page {
		background-color: red;
	} */
</style>
