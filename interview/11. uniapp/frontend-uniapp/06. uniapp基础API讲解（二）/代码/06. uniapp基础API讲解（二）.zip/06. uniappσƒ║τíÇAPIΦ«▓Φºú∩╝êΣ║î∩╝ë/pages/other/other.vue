<template>
	<view>
		v<view class="box">
			box
		</view>
	</view>
</template>

<script>
	export default {
		onLoad(params) {
			console.log(params)
		},
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.box {
		width: 375rpx;
		height: 375rpx;
		background-color: red;
	}
</style>
