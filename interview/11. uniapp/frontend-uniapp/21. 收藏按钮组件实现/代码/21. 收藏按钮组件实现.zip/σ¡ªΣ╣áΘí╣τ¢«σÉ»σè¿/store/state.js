export default {
  userInfo: uni.getStorageSync('userInfo') || null
}