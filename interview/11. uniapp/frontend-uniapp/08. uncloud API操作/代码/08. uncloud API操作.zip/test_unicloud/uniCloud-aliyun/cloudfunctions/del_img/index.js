'use strict';
exports.main = async (event, context) => {
	//event为客户端上传的参数
	const res = await uniCloud.deleteFile({
		fileList:['https://vkceyugu.cdn.bspapp.com/VKCEYUGU-db8c615e-f754-47dd-8959-c18d71af090c/4cd118f0-36ca-4787-b35d-d810e3610576.jpg']
	})
	
	console.log(res)
	
	//返回数据给客户端
	return event
};
