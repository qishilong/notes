<template>
	<view>
		<text>用户名</text>
		<input type="text" v-model="userName" />
		<text>年龄</text>
		<input type="text" v-model="age" />
		<button type="default" @click="_sendUserInfo">提交表单</button>
		<view class="list">
			用户列表
		</view>
		<view class="list-wrapper">
			<view class="list" v-for="(item,index) in userList" :key="index">
				<text>{{item.userName}}</text>
				<button type="default" size="mini" @click="_delUser(item._id)">删除</button>
			</view>
		</view>
		<button type="default" @click="uploadFile">上传图片</button>
	</view>
</template>

<script>
	export default {
		onLoad() {
			this._inituserInfo()
		},
		data() {
			return {
				userName: '',
				age: '',
				userList: null
			}
		},
		methods: {
			async _sendUserInfo() {
				const res = await uniCloud.callFunction({
					name: 'add_user',
					data: {
						userName: this.userName,
						age: this.age
					}
				})
			},
			async _inituserInfo() {
				const data = await uniCloud.callFunction({
					name: 'get_user'
				})
				this.userList = data.result.list
			},
			async _delUser(_id) {
				const res = await uniCloud.callFunction({
					name: 'del_user',
					data: {
						_id
					}
				})
				console.log(res)
			},
			uploadFile() {
				uni.chooseImage({
					success(res) {
						// console.log(res.tempFilePaths[0])
						uniCloud.uploadFile({
							cloudPath:'test.jpg',   // 文件名
							filePath:res.tempFilePaths[0],    // 文件信息
							success(res) {
								console.log(res)
							}
						})
					}
				})
			}
		},
	}
</script>

<style scoped lang="scss">
	.list {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
</style>
