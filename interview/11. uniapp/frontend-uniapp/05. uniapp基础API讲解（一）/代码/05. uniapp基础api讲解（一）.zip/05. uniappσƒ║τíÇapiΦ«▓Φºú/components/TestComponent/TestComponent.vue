<template>
	<view>
		test component page
		<text>接受父组件传递的数据：</text>
		{{parentData}}
	</view>
</template>

<script>
	export default {
		name:"TestComponent",
		props:{
			parentData:String
		},
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
