<template>
	<view>
		<view class="">
			view tag
			<text>text1</text>
			<text>text2</text>
		</view>
		<scroll-view @scrolltolower="scrolltolower" class="scroll-view" scroll-y="true">
			<!-- x轴的滚动  保证我们的scrollview 有一个高度-->
			<view v-for="item in 200">{{item}}</view>
		</scroll-view>
		<swiper @change="changeItem" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000">
			<swiper-item item-id="1">
				<view class="swiper-item">1</view>
			</swiper-item>
			<swiper-item item-id="2">
				<view class="swiper-item">2</view>
			</swiper-item>
		</swiper>
		<icon type="success" size="26" />
		<uni-icons size="26" type="arrowdown"></uni-icons>
		<text>{{msg}}</text>
		<rich-text :nodes="msg"></rich-text>
		<input type="text"  v-model="testValue" />
		<view class="">
			{{testValue}}
		</view>
		<button type="warn" @click="goOtherPage">跳转到other界面</button>
		<navigator open-type="redirect" url="../other/other">跳转到其他界面</navigator>
		<view class="" v-if="isShow">
			根据条件进行显示
		</view>
	</view>
</template>


<script>
	export default {
		data() {
			return  {
				msg: "<div>hello world</div>",
				testValue:"初始化数据内容",
				isShow:true
			}
		},
		methods: {
			scrolltolower() {
				// console.log('ended')
			},
			changeItem(e) {
				// console.log(e)
			},
			goOtherPage() {
				uni.navigateTo({
					url:'/pages/other/other',
					success(res) {
						console.log(res)
					}
				})
			}
		},
	}
</script>

<style scoped>
	.scroll-view {
		height: 200px;
	}
</style>
