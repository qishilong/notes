<template>
	<view>
		other page
		<TestComponent :parentData="parentData"></TestComponent>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				parentData:"父组件的数据"
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
