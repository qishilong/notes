<script>
	export default {
		// app.js 文件 生命周期 uniapp创建完成
		// onLaunch: function() {
		// 	console.log('App Launch')
		// },
		// onShow: function() { 
		// 	console.log('App Show')
		// },
		// onHide: function() {
		// 	console.log('App Hide')
		// }
	}
</script>

<style>
	/*每个页面公共css */
</style>
