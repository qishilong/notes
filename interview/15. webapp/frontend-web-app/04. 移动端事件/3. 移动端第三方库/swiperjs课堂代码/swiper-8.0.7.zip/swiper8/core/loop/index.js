import loopCreate from './loopCreate.js';
import loopFix from './loopFix.js';
import loopDestroy from './loopDestroy.js';
export default {
  loopCreate,
  loopFix,
  loopDestroy
};