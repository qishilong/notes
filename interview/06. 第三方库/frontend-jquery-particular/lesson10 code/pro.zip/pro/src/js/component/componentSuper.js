var ComponentSuperFactory = function () {

}